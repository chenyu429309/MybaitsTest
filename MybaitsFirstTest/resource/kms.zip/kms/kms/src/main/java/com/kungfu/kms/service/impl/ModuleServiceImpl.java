package com.kungfu.kms.service.impl;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.kungfu.kms.domain.ModuleInfo;
import com.kungfu.kms.mapper.ModuleMapper;
import com.kungfu.kms.service.ModuleService;

@Service
public class ModuleServiceImpl implements ModuleService {
	private Logger log = LogManager.getLogger(getClass());
	@Autowired
	private ModuleMapper moduleMapper;

	/**
	 * 0804 获取角色模块
	 * 
	 * @param userId
	 * @return
	 */
	@Cacheable(value = "usercache", keyGenerator = "wiselyKeyGenerator")
	public List<ModuleInfo> findModuleByUserId(int userId) {
		log.info("为缓存,userId: {}", userId);
		return moduleMapper.findModuleByUserId(userId);
	}
}
