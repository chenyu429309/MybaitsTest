package com.kungfu.kms.service;

import java.util.List;

import com.kungfu.kms.domain.ModuleInfo;

public interface ModuleService {
	/**
	 * 获取角色模块
	 * @param userId
	 * @return
	 */
	List<ModuleInfo> findModuleByUserId(int userId);
}
