package com.kungfu.kms.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.kungfu.kms.domain.Role;
import com.kungfu.kms.service.RoleService;

@Controller
public class IndexController {
	@Autowired
	private RoleService roleService;

	/**
	 * Go Index
	 * 
	 * @return
	 */
	@RequestMapping(value = { "", "/", "index" })
	public String index() {
		return "index.jsp";
	}

	/**
	 * unauthor
	 * 
	 * @return
	 */
	@RequestMapping("unauthor")
	public String unauthor() {
		return "unauthor.jsp";
	}

	/**
	 * reports
	 * 
	 * @return
	 */
	@RequestMapping("reports")
	public String reports() {
		return "reports.jsp";
	}

	/**
	 * reports
	 * 
	 * @return
	 */
	@RequestMapping("tab")
	public String tab() {
		return "tab.jsp";
	}

	/**
	 * 角色管理首页
	 * 
	 * @return
	 */
	@RequestMapping("Role_mgt")
	public ModelAndView roleIndex() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("/system/role/index.jsp");
		List<Role> roleList = roleService.getRoleList();
		mv.addObject("roleList", roleList);
		return mv;
	}
}
