package com.kungfu.kms.vo;

import java.io.Serializable;
import java.util.List;

public class ModuleVo implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 5672383225327976236L;
	private String id;    //模块ID
	private String name;  //模块名称
	private String icon;  //模块图标
	private List<MenuItem> sons;  //子菜单
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getIcon() {
		return icon;
	}
	public void setIcon(String icon) {
		this.icon = icon;
	}
	public List<MenuItem> getSons() {
		return sons;
	}
	public void setSons(List<MenuItem> sons) {
		this.sons = sons;
	}
	
}
