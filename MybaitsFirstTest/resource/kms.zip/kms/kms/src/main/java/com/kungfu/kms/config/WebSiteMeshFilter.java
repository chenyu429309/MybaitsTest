package com.kungfu.kms.config;

import org.sitemesh.builder.SiteMeshFilterBuilder;
import org.sitemesh.config.ConfigurableSiteMeshFilter;

public class WebSiteMeshFilter extends ConfigurableSiteMeshFilter {

	@Override
	protected void applyCustomConfiguration(SiteMeshFilterBuilder builder) {
		builder.addDecoratorPath("/kms/*", "/kms/index")
		       .addDecoratorPath("/tab","/WEB-INF/views/index.jsp")
		       .addDecoratorPath("/Role_mgt","/WEB-INF/views/index.jsp")
				.addExcludedPath("/kms/index")
				.addExcludedPath("/plugin/*");
	}
}