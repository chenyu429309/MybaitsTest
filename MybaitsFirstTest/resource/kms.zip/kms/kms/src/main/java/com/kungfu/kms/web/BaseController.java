package com.kungfu.kms.web;

 

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;

import javax.annotation.Resource;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.MessageSource;
import org.springframework.context.MessageSourceAware;
import org.springframework.web.context.ServletContextAware;

/**
 * 系统公共控制处理类
 * @author pengchao
 *
 */
public class BaseController  implements ServletContextAware, MessageSourceAware {

	public static final String path_seperator = File.separator;//"/";
	public static final String basic_folder = "static"+path_seperator;
	
	public static final String first_folder_name = "gif_folder";
	public static final String first_folder = first_folder_name + path_seperator;
	
	public static final String image_folder_name = "images";
	public static final String image_folder = image_folder_name + path_seperator;
	
	public static final String news_folder_name = "news";
	public static final String news_folder = news_folder_name + path_seperator;
	
	public static final String category_folder_name = "category";
	public static final String category_folder = category_folder_name + path_seperator;
	
	public static final String pdf_folder_name = "pdf";
	public static final String pdf_folder = pdf_folder_name + path_seperator;
	public static final String msg_default_infourl = "infourl.default";
	
	
	protected ServletContext context;
	protected String webRoot;
	protected String uploadRoot;
	protected String contextRoot;
	protected MessageSource messageSource;
	
	 /** http请求对象 */
    private HttpServletRequest request;

    protected Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    public HttpServletRequest getRequest()
    {
        return request;
    }

    @Resource
    public void setRequest(HttpServletRequest request)
    {
        this.request = request;
    }
	
	public void setServletContext(ServletContext context) {
		this.context = context;
		this.webRoot = context.getRealPath("/");
		this.contextRoot = context.getContextPath();
		// 用webapp路径
		this.uploadRoot = new File(this.webRoot).getParent() + File.separator+basic_folder;
		LOGGER.debug("set upload root = " + uploadRoot);
	} 
	
	public String getParameter(String name){
		return getRequest().getParameter(name);
	}
	
	public HttpSession getSession(){
		return getRequest().getSession();
	}
	
	public Object getSessionMenu(){
		return getSession().getAttribute(Constant.SESSION_MENUS);
	}
	
	/**
	 * 应答请求
	 * @param msg 应答内容
	 * @throws IOException 
	 */
	public void askedRequest(HttpServletResponse response, String msg) throws IOException{
		if(response!=null){
			response.setContentType("text/html;charset=utf-8");
			PrintWriter p = null;
			p = response.getWriter();
			p.print(msg);
			p.flush();
			p.close();
			LOGGER.debug("response msg:", msg);
		}
	}
	
	/**
	 * 将系统异常对象转字符串
	 * @param e 异常对象
	 * @return
	 */
	public String exceptionToString(Exception e){
		StringWriter w = new StringWriter();
		e.printStackTrace(new PrintWriter(w));
		return w.toString().replaceAll("\n", "<br/>").replaceAll("\r", "<br/>")
				.replaceAll("<br/><br/>", "<br/>");
	}
	
	 

	@Override
	public void setMessageSource(MessageSource messageSource) {
		this.messageSource = messageSource;
	}
	
	public String getIpAddr(HttpServletRequest request) {
		String ip = request.getHeader("x-forwarded-for");
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("Proxy-Client-IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("WL-Proxy-Client-IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getRemoteAddr();
		}
		return ip;
	}
}
