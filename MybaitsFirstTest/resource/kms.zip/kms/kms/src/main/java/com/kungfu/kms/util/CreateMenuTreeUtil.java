package com.kungfu.kms.util;

import java.util.ArrayList;
import java.util.List;

import com.kungfu.kms.domain.ModuleInfo;
import com.kungfu.kms.vo.MenuItem;
import com.kungfu.kms.vo.ModuleVo;

public class CreateMenuTreeUtil {
	public static List<ModuleVo> createMenuTree(List<ModuleInfo> modules){
		List<ModuleVo> mList = new ArrayList<>();
		for(ModuleInfo m :modules){
			if(m.getPid() == 0){
				ModuleVo info = new ModuleVo();
				info.setIcon(m.getIcon());
				info.setId(m.getId()+"");
				info.setName(m.getModuleName());
				//获取子节点
				info.setSons(getMenuItem(m.getId(),modules));
				mList.add(info);
			}
		}
		
		return mList;
	}
	
	private static List<MenuItem> getMenuItem(final int pid,final List<ModuleInfo> modules){
		List<MenuItem> list = new ArrayList<>();
		for(ModuleInfo m :modules){
			if(m.getPid() == pid){
				MenuItem item = new MenuItem();
				item.setId(m.getId()+"");
				item.setName(m.getModuleName());
				item.setUrl(m.getModulePath());
				list.add(item);
			}
		}
		return list;
	}
}
