package com.kungfu.kms.web;

public interface Constant {
	public static final String SESSION_MENUS = "SESSION_MENUS";
	public static final String SESSION_USER = "SESSION_USER";
}
