package com.kungfu.kms.util;

import java.beans.PropertyDescriptor;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.PropertyUtils;

/**
 * string util
 * 
 */
public class StringUtil {

	/**
	 * check if two strings are equal
	 * 
	 * @param string1
	 * @param string2
	 * @return
	 */
	public static boolean equals(String string1, String string2) {
		return (string1 == null && string2 == null)
				|| (string1 != null && string1.equals(string2));
	}

	/**
	 * check if two strings are equal ignore case
	 * 
	 * @param string1
	 * @param string2
	 * @return
	 */
	public static boolean equalsIgnoreCase(String string1, String string2) {
		return (string1 == null && string2 == null)
				|| (string1 != null && string1.equalsIgnoreCase(string2));
	}

	/**
	 * check if string is empty
	 * 
	 * @param string
	 * @return
	 */
	public static boolean isEmpty(String string) {
		return string == null || string.trim().equals("");
	}

	/**
	 * check if string is not empty
	 * 
	 * @param string
	 * @return
	 */
	public static boolean isNotEmpty(String string) {
		return !isEmpty(string);
	}

	/**
	 * split string with regex, and return list of non-empty items with leading
	 * and trailing whitespace omitted
	 * 
	 * @param string
	 * @param regex
	 * @return
	 */
	public static List<String> splitIgnoreEmpty(String string, String regex) {
		if (isEmpty(string)) {
			return null;
		}
		String[] array = string.split(regex);
		List<String> list = new ArrayList<String>(array.length);
		for (String item : array) {
			if (isNotEmpty(item)) {
				list.add(item.trim());
			}
		}
		return list;
	}

	public static String chgNull(String in) {
		String out = null;
		out = in;
		if (out == null || (out.trim()).equals("null")) {
			return "";
		} else {
			return out.trim();
		}
	}

	/**
	 * substring for overflow
	 * 
	 * @param source
	 * @param beginIndex
	 *            can be null, default is 0
	 * @param endIndex
	 *            can be null, default is source.length()
	 * @return
	 */
	public static String overflow(String source, Integer beginIndex,
			Integer endIndex) {
		source = source == null ? "" : source.trim();
		beginIndex = beginIndex == null ? 0 : beginIndex;
		endIndex = endIndex == null ? source.length() : endIndex;
		if (beginIndex < 0
				|| endIndex > source.length()
				|| beginIndex >= endIndex
				|| (beginIndex.intValue() == 0 && endIndex.intValue() == source
						.length())) {
			return source;
		}
		return source.substring(beginIndex, endIndex) + " ...";
	}

	/**
	 * substring for overflow by bite
	 * 
	 * @param source
	 * @param length
	 * @return
	 */
	public static String overflow2(String source, Integer length) {
		StringBuffer sb = new StringBuffer();
		int charlen = 0;
		int strlength = source.length();
		for (int i = 0; i < strlength; i++) {
			int asciiCode = source.codePointAt(i);
			if (asciiCode >= 0 && asciiCode <= 255) {
				charlen += 1;
			} else {
				charlen += 2;
			}

			if (charlen <= length) {
				sb.append(source.charAt(i));
			} else {
				break;
			}
		}
		return sb.toString().length() < strlength ? sb.toString() + "..." : sb
				.toString();
	}

	public static String toUpperCaseFirstLetter(String name) {
		if (isEmpty(name)) {
			return "";
		}
		name = name.trim();
		if (name.length() > 0) {
			return name.substring(0, 1).toUpperCase() + name.substring(1);
		}
		return "";
	}

	public static Object trimObj(Object model) {
		Field[] field = model.getClass().getDeclaredFields(); // 获取实体类的所有属性，返回Field数组
		try {
			for (int j = 0; j < field.length; j++) { // 遍历所有属性
				String name = field[j].getName(); // 获取属性的名字
				// System.out.println("attribute name:"+name);
				String type = field[j].getGenericType().toString(); // 获取属性的类型
				if (type.equals("class java.lang.String")) { // 如果type是类类型，则前面包含"class "，后面跟类名
					Method m = model.getClass().getMethod(
							"get" + toUpperCaseFirstLetter(name));
					String value = (String) m.invoke(model); // 调用getter方法获取属性值
					if (value != null && "".equals(value)) {
						field[j].setAccessible(true);
						field[j].set(model, null);
						field[j].setAccessible(false);
					}
				}
				/*
				 * if(type.equals("class java.lang.Integer")){ Method m =
				 * model.getClass().getMethod("get"+name); Integer value =
				 * (Integer) m.invoke(model); if(value != null){
				 * System.out.println("attribute value:"+value); } }
				 * if(type.equals("class java.lang.Short")){ Method m =
				 * model.getClass().getMethod("get"+name); Short value = (Short)
				 * m.invoke(model); if(value != null){
				 * System.out.println("attribute value:"+value); } }
				 * if(type.equals("class java.lang.Double")){ Method m =
				 * model.getClass().getMethod("get"+name); Double value =
				 * (Double) m.invoke(model); if(value != null){
				 * System.out.println("attribute value:"+value); } }
				 * if(type.equals("class java.lang.Boolean")){ Method m =
				 * model.getClass().getMethod("get"+name); Boolean value =
				 * (Boolean) m.invoke(model); if(value != null){
				 * System.out.println("attribute value:"+value); } }
				 * if(type.equals("class java.util.Date")){ Method m =
				 * model.getClass().getMethod("get"+name); Date value = (Date)
				 * m.invoke(model); if(value != null){
				 * System.out.println("attribute value:"
				 * +value.toLocaleString()); } }
				 */
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return model;
	}

	/**
	 * describe object as string
	 * 
	 * @param bean
	 * @return
	 * @author Dina
	 */
	public static String describe(Object bean) {
		StringBuffer description = new StringBuffer();
		PropertyDescriptor[] descriptors = PropertyUtils
				.getPropertyDescriptors(bean.getClass());
		String name;
		String value;
		for (PropertyDescriptor descriptor : descriptors) {
			name = descriptor.getName();
			try {
				value = BeanUtils.getProperty(bean, name);
			} catch (Exception e) {
				value = "exception";
			}
			description.append(";" + name + "=" + value);
		}
		return "["
				+ (description.length() > 0 ? description.substring(1)
						: description.toString()) + "]";
	}

	/**
	 * 将元数据前补零，补后的总长度为指定的长度，以字符串的形式返回
	 * 
	 * @param sourceDate
	 * @param formatLength
	 * @return 重组后的数据
	 */
	public static String frontCompWithZore(int sourceDate, int formatLength) {
		/*
		 * 0 指前面补充零 formatLength 字符总长度为 formatLength d 代表为正数。
		 */
		String newString = String.format("%0" + formatLength + "d", sourceDate);
		return newString;
	}

	/**
	 * get byte count in utf-8
	 * 
	 * @param text
	 * @return
	 * @author Dina
	 * @throws UnsupportedEncodingException
	 */
	public static int getByteCountUtf8(String text)
			throws UnsupportedEncodingException {
		return getByteCount(text, "UTF-8");
	}

	/**
	 * get byte count in charset
	 * 
	 * @param text
	 * @param charset
	 * @return
	 * @author Dina
	 * @throws UnsupportedEncodingException
	 */
	public static int getByteCount(String text, String charset)
			throws UnsupportedEncodingException {
		if (text == null) {
			return 0;
		}
		return text.getBytes(charset).length;
	}

	/**
	 * filter off utf8 mb4
	 * 
	 * @param text
	 * @return
	 * @throws UnsupportedEncodingException
	 * @author Dina
	 */
	public static String filterOffUtf8Mb4(String text)
			throws UnsupportedEncodingException {
		byte[] bytes = text.getBytes("UTF-8");
		ByteBuffer buffer = ByteBuffer.allocate(bytes.length);
		int i = 0;
		while (i < bytes.length) {
			short b = bytes[i];
			if (b > 0) {
				buffer.put(bytes[i++]);
				continue;
			}
			b += 256;
			if ((b ^ 0xC0) >> 4 == 0) {
				buffer.put(bytes, i, 2);
				i += 2;
			} else if ((b ^ 0xE0) >> 4 == 0) {
				buffer.put(bytes, i, 3);
				i += 3;
			} else if ((b ^ 0xF0) >> 4 == 0) {
				buffer.put((byte) 0x3F);
				i += 4;
			}
		}
		buffer.flip();
		return new String(buffer.array(), "UTF-8");
	}

	/**
	 * encode in UTF8
	 * 
	 * @param text
	 * @return
	 * @author Dina
	 */
	public static String encodeUTF8(String text) {
		String textEncoded = null;
		try {
			textEncoded = URLEncoder.encode(text, "UTF-8");
		} catch (Exception e) {
			textEncoded = null;
		}
		return textEncoded;
	}

	/**
	 * decode from UTF8
	 * 
	 * @param text
	 * @return
	 * @author Dina
	 */
	public static String decodeUTF8(String text) {
		String textDecoded = null;
		try {
			textDecoded = URLDecoder.decode(text, "UTF-8");
		} catch (Exception e) {
			textDecoded = null;
		}
		return textDecoded;
	}

	/**
	 * format data
	 * 
	 * @param data
	 * @return
	 * @author Dina
	 */
	public static String formatData(long data) {
		if (data < 1000) {
			return String.valueOf(data);
		} else if (data >= 1000 && data <= 9999) {
			return (data / 1000) + "k";
		} else {
			return (data / 10000) + "w+";
		}
	}

	/**
	 * format data
	 * 
	 * @param data
	 * @return
	 * @author Dina
	 */
	public static String formatData2(long data) {
		if (data < 10000) {
			return String.valueOf(data);
		} else {
			return (data / 10000) + "w+";
		}
	}

	/**
	 * random number
	 * 
	 * @param length
	 * @return
	 */
	public static String randomNumber(int length) {
		Random random = new Random();
		Long number = Math.abs(random.nextLong());
		return String.valueOf(number).substring(0, length);
	}

	/**
	 * random number or character
	 * 
	 * @param length
	 * @return
	 */
	public static String randomNumOrChar(int length) {
		StringBuffer stringBuffer = new StringBuffer();
		Random random = new Random();
		for (int i = 0; i < length; i++) {
			if (random.nextBoolean()) {
				stringBuffer
						.append((char) ((random.nextBoolean() ? 65 : 97) + random
								.nextInt(26)));
			} else {
				stringBuffer.append(random.nextInt(10));
			}
		}
		return stringBuffer.toString();
	}

	

	public static String replaceIgnoreCase(String input, String regex,
			String replacePre, String replacePost) {
		Pattern pattern = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
		Matcher matcher = pattern.matcher(input);
		StringBuffer sb = new StringBuffer();
		while (matcher.find()) {
			matcher.appendReplacement(sb, replacePre + matcher.group()
					+ replacePost);
		}
		matcher.appendTail(sb);
		return sb.toString();
	}

	public static Double getDouble(Double doub) {
		long l1 = Math.round(doub * 100); // 四舍五入
		double ret = l1 / 100.0; // 注意：使用 100.0 而不是 100
		return ret;
	}

	public static Double getDouble(Double doub, int n) {
		long l1 = Math.round(doub * 10 * n); // 四舍五入
		double ret = l1 / (10.0 * 10); // 注意：使用 100.0 而不是 100
		return ret;
	}
	
	 public static String listToString(List<Integer> list){
	        String strIds=null;
	        if(list!=null && list.size()>0){
	        	for(Integer objI:list){
	        		if(StringUtil.isNotEmpty(strIds)){
	        			strIds+=","+String.valueOf(objI);
	        		}else {
	        			strIds=String.valueOf(objI);
	        		}
	        	}
	        }
	        return strIds;
	 }
	 
	 public static String mapToString(Map<String, Boolean> map){
		 String strIds=null;
		if(map!=null && map.size()>0){
			for (Map.Entry<String, Boolean> objM : map.entrySet())  {  
				if(StringUtil.isNotEmpty(strIds)){
					strIds+=","+objM.getKey();
				}else {
					strIds=objM.getKey();
				}
	        }
		}
		return strIds; 
	 }
	 
	 public static void main(String[] args) {
		List<Integer> list=new ArrayList<Integer>();
		 for(int i=0;i<50;i++){
			 list.add(i);
			
		}
		 System.out.println("============s======="+listToString(list));
	}
}
