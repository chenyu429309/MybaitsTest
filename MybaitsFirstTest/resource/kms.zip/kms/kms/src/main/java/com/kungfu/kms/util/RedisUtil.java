package com.kungfu.kms.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Set;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

/**
 * RedisUtil
 * 
 * @author John
 * @version 1.0 2015/10/15
 */
public class RedisUtil {

	private static JedisPool pool = null;

	/**
	 * establish JedisPool
	 * 
	 * @param ip
	 * @param port
	 * @return JedisPool
	 */
	public static JedisPool getPool() {
		if (pool == null) {
			ResourceBundle bundle = ResourceBundle.getBundle("redis");
			if (bundle == null) {
				throw new IllegalArgumentException("[redis.properties] is not found!");
			}
			JedisPoolConfig config = new JedisPoolConfig();
			config.setMaxIdle(Integer.valueOf(bundle.getString("redis.pool.maxIdle")));
			config.setMaxTotal(Integer.valueOf(bundle.getString("redis.pool.maxTotal")));
			config.setMinIdle(Integer.valueOf(bundle.getString("redis.pool.minIdle")));
			String redisHost = bundle.getString("redis.pool.host");
			int redisPort = Integer.valueOf(bundle.getString("redis.pool.port"));
			int redisTimeOut = Integer.valueOf(bundle.getString("redis.pool.timeOut"));
			String redisPassword = bundle.getString("redis.pool.password");
			// String
			pool = new JedisPool(config, redisHost, redisPort, redisTimeOut, redisPassword);
		}
		return pool;
	}

	/**
	 * return redis connection to its pool
	 * 
	 * @param pool
	 * @param redis
	 */
	public static void returnResource(JedisPool pool, Jedis redis) {
		if (redis != null) {
			pool.returnResourceObject(redis);
		}
	}

	/**
	 * Test if the specified key exists. The command returns true if the key exists, otherwise false is returned.
	 * 
	 * @param key
	 * @return
	 */
	public static Boolean exists(String key) {
		Boolean value = false;

		JedisPool pool = null;
		Jedis jedis = null;
		try {
			pool = getPool();
			jedis = pool.getResource();
			value = jedis.exists(key);
		} catch (Exception e) {
			// 释放redis对象
			pool.returnResourceObject(jedis);
			e.printStackTrace();
		} finally {
			// 返还到连接池
			returnResource(pool, jedis);
		}

		return value;
	}

	/**
	 * Return the type of the value stored at key in form of a string
	 * 
	 * @param key
	 * @return The type can be one of "none", "string", "list", "set". "none" is returned if the key does not exist
	 */
	public static String type(String key) {
		String value = null;

		JedisPool pool = null;
		Jedis jedis = null;
		try {
			pool = getPool();
			jedis = pool.getResource();
			value = jedis.type(key);
		} catch (Exception e) {
			// 释放redis对象
			pool.returnResourceObject(jedis);
			e.printStackTrace();
		} finally {
			// 返还到连接池
			returnResource(pool, jedis);
		}

		return value;
	}

	/**
	 * Return the remaining time to live in seconds of a key that has an EXPIRE set
	 * 
	 * @param key
	 * @return If the Key does not have an associated expire, -1 is returned or if the Key does not exists, -2 is returned
	 */
	public static Long ttl(String key) {
		Long value = 0l;

		JedisPool pool = null;
		Jedis jedis = null;
		try {
			pool = getPool();
			jedis = pool.getResource();
			value = jedis.ttl(key);
		} catch (Exception e) {
			// 释放redis对象
			pool.returnResourceObject(jedis);
			e.printStackTrace();
		} finally {
			// 返还到连接池
			returnResource(pool, jedis);
		}

		return value;
	}

	/**
	 * Set a timeout on the specified key
	 * 
	 * @param key
	 * @param seconds
	 * @return 1: the timeout was set. 0: the timeout was not set
	 */
	public static Long expire(String key, int seconds) {
		Long value = 0l;

		JedisPool pool = null;
		Jedis jedis = null;
		try {
			pool = getPool();
			jedis = pool.getResource();
			value = jedis.expire(key, seconds);
		} catch (Exception e) {
			// 释放redis对象
			pool.returnResourceObject(jedis);
			e.printStackTrace();
		} finally {
			// 返还到连接池
			returnResource(pool, jedis);
		}

		return value;
	}

	/**
	 * Expire at the given UNIX timestamp
	 * 
	 * @param key
	 * @param unixTime
	 * @return 1: the timeout was set. 0: the timeout was not set
	 */
	public static Long expireAt(String key, long unixTime) {
		Long value = 0l;

		JedisPool pool = null;
		Jedis jedis = null;
		try {
			pool = getPool();
			jedis = pool.getResource();
			value = jedis.expireAt(key, unixTime);
		} catch (Exception e) {
			// 释放redis对象
			pool.returnResourceObject(jedis);
			e.printStackTrace();
		} finally {
			// 返还到连接池
			returnResource(pool, jedis);
		}

		return value;
	}

	/**
	 * Undo a expire at turning the expire key into a normal key.
	 * 
	 * @param key
	 * @return Integer reply, specifically: 1: the key is now persist. 0: the key is not persist (only happens when key not set).
	 */
	public static Long persist(String key) {
		Long value = 0l;

		JedisPool pool = null;
		Jedis jedis = null;
		try {
			pool = getPool();
			jedis = pool.getResource();
			value = jedis.persist(key);
		} catch (Exception e) {
			// 释放redis对象
			pool.returnResourceObject(jedis);
			e.printStackTrace();
		} finally {
			// 返还到连接池
			returnResource(pool, jedis);
		}

		return value;
	}

	/**
	 * Move the specified key from the currently selected DB to the specified destination DB.
	 * 
	 * @param key
	 * @param dbIndex
	 * @return 1 if the key was moved 0 if the key was not moved because already present on the target DB or was not found in the current DB.
	 */
	public static Long move(String key, int dbIndex) {
		Long value = 0l;

		JedisPool pool = null;
		Jedis jedis = null;
		try {
			pool = getPool();
			jedis = pool.getResource();
			value = jedis.move(key, dbIndex);
		} catch (Exception e) {
			// 释放redis对象
			pool.returnResourceObject(jedis);
			e.printStackTrace();
		} finally {
			// 返还到连接池
			returnResource(pool, jedis);
		}

		return value;
	}

	/**
	 * Atomically renames the key oldkey to newkey. If newkey already exists it is overwritten
	 * 
	 * @param oldkey
	 * @param newkey
	 * @return 1 if the key was renamed 0 if the key was not renamed. -1 if the newkey is equal to the oldkey. -2 if oldkey does not exist.
	 */
	public static Long rename(String oldkey, String newkey) {
		Long value = 0l;
		if (StringUtil.equalsIgnoreCase(oldkey, newkey)) {
			return -1l;
		}
		JedisPool pool = null;
		Jedis jedis = null;
		try {
			pool = getPool();
			jedis = pool.getResource();
			if (!jedis.exists(oldkey)) {
				return -2l;
			}
			String renameResult = jedis.rename(oldkey, newkey);
			if (StringUtil.equalsIgnoreCase(renameResult, "OK")) {
				value = 1l;
			}
		} catch (Exception e) {
			// 释放redis对象
			pool.returnResourceObject(jedis);
			e.printStackTrace();
		} finally {
			// 返还到连接池
			returnResource(pool, jedis);
		}

		return value;
	}

	/**
	 * Atomically renames the key oldkey to newkey. If newkey already exists this operation fails.
	 * 
	 * @param oldkey
	 * @param newkey
	 * @return 1 if the key was renamed 0 if the key was not renamed. -1 if the newkey is equal to the oldkey. -2 if oldkey does not exist.
	 */
	public static Long renameNx(String oldkey, String newkey) {
		Long value = 0l;
		if (StringUtil.equalsIgnoreCase(oldkey, newkey)) {
			return -1l;
		}
		JedisPool pool = null;
		Jedis jedis = null;
		try {
			pool = getPool();
			jedis = pool.getResource();
			if (!jedis.exists(oldkey)) {
				return -2l;
			}
			value = jedis.renamenx(oldkey, newkey);
		} catch (Exception e) {
			// 释放redis对象
			pool.returnResourceObject(jedis);
			e.printStackTrace();
		} finally {
			// 返还到连接池
			returnResource(pool, jedis);
		}

		return value;
	}

	/**
	 * Del the key-value set from redis by key.
	 * 
	 * @param key
	 * @return 1 if deleted. 0 if failed or the key-value set does not exist.
	 */
	public static Long del(String key) {
		Long value = 0l;
		JedisPool pool = null;
		Jedis jedis = null;
		try {
			pool = getPool();
			jedis = pool.getResource();
			value = jedis.del(key);
		} catch (Exception e) {
			// 释放redis对象
			pool.returnResourceObject(jedis);
			e.printStackTrace();
		} finally {
			// 返还到连接池
			returnResource(pool, jedis);
		}

		return value;
	}

	/**
	 * Get the string value of the specified key. If the key does not exist null is returned
	 * 
	 * @param key
	 * @return
	 */
	public static String get(String key) {
		String value = null;

		JedisPool pool = null;
		Jedis jedis = null;
		try {
			pool = getPool();
			jedis = pool.getResource();
			value = jedis.get(key);
		} catch (Exception e) {
			// 释放redis对象
			pool.returnResourceObject(jedis);
			e.printStackTrace();
		} finally {
			// 返还到连接池
			returnResource(pool, jedis);
		}

		return value;
	}

	/**
	 * Set the obj as string value of the key. The string of obj can't be longer than 1073741824 bytes(1GB)
	 * 
	 * @param key
	 * @param obj
	 * @return
	 */
	public static String set(String key, Object obj) {
		String statusCode = null;

		JedisPool pool = null;
		Jedis jedis = null;
		try {
			pool = getPool();
			jedis = pool.getResource();
			String objectStr = JsonUtil.getJsonStr(obj);
			statusCode = jedis.set(key, objectStr);
		} catch (Exception e) {
			// 释放redis对象
			pool.returnResourceObject(jedis);
			e.printStackTrace();
		} finally {
			// 返还到连接池
			returnResource(pool, jedis);
		}

		return statusCode;
	}

	/**
	 * Set. If the key already exists no operation is performed.
	 * 
	 * @param key
	 * @param obj
	 * @return 1 if the key was set 0 if the key was not set
	 */
	public static Long setNx(String key, Object obj) {
		Long result = null;

		JedisPool pool = null;
		Jedis jedis = null;
		try {
			pool = getPool();
			jedis = pool.getResource();
			String objectStr = JsonUtil.getJsonStr(obj);
			result = jedis.setnx(key, objectStr);
		} catch (Exception e) {
			// 释放redis对象
			pool.returnResourceObject(jedis);
			e.printStackTrace();
		} finally {
			// 返还到连接池
			returnResource(pool, jedis);
		}

		return result;
	}

	/**
	 * The command is exactly equivalent to the following group of commands: SET + EXPIRE. The operation is atomic.
	 * 
	 * @param key
	 * @param seconds
	 * @param obj
	 * @return OK is returned if operation succeed. Otherwise no operation is performed.
	 */
	public static String setEx(String key, int seconds, Object obj) {
		String statusCode = null;

		JedisPool pool = null;
		Jedis jedis = null;
		try {
			pool = getPool();
			jedis = pool.getResource();
			String objectStr = JsonUtil.getJsonStr(obj);
			statusCode = jedis.setex(key, seconds, objectStr);
		} catch (Exception e) {
			// 释放redis对象
			pool.returnResourceObject(jedis);
			e.printStackTrace();
		} finally {
			// 返还到连接池
			returnResource(pool, jedis);
		}

		return statusCode;
	}

	/**
	 * SET & EXPIRE. If the key already exists no operation is performed
	 * 
	 * @param key
	 * @param seconds
	 * @param obj
	 * @return 1 if succeed. 0 if failed or the key already exists.
	 */
	public static Long setNxWithEx(String key, int seconds, Object obj) {
		Long result = 0l;

		JedisPool pool = null;
		Jedis jedis = null;
		try {
			pool = getPool();
			jedis = pool.getResource();
			if (jedis.exists(key)) {
				return result;
			}
			String objectStr = JsonUtil.getJsonStr(obj);
			String resultStr = jedis.setex(key, seconds, objectStr);
			if (StringUtil.equalsIgnoreCase(resultStr, "OK")) {
				result = 1l;
			}
		} catch (Exception e) {
			// 释放redis对象
			pool.returnResourceObject(jedis);
			e.printStackTrace();
		} finally {
			// 返还到连接池
			returnResource(pool, jedis);
		}

		return result;
	}
	
	/**	
	 * Set the the respective keys to the respective values. mset will replace old values with new values.
	 * 
	 * @param keysvalues
	 * @return
	 * 		Integer reply. Basically 1 as mset can't fail
	 */
	public static Long mset(String... keysvalues){  
		Long result = 0l;

		JedisPool pool = null;
		Jedis jedis = null;
        try {  
              
        	pool = getPool();
			jedis = pool.getResource();
            String resultStr = jedis.mset(keysvalues);
            if(StringUtil.equalsIgnoreCase(resultStr, "OK")){
            	result = 1l;
            }
        } catch (Exception e) {  
        	// 释放redis对象
			pool.returnResourceObject(jedis);
			e.printStackTrace();
        } finally {  
        	// 返还到连接池
			returnResource(pool, jedis);
        }  
    	return result;
    }

	/**
	 * Get the value of the specified key and convert it to <T> Object
	 * 
	 * @param key
	 * @return
	 */
	public static <T> Object getBean(String key, Class<T> type) {
		Object bean = null;

		JedisPool pool = null;
		Jedis jedis = null;
		try {
			pool = getPool();
			jedis = pool.getResource();
			String value = jedis.get(key);
			bean = StringUtil.isEmpty(value) ? null : JsonUtil.parseObject(value, type);
		} catch (Exception e) {
			// 释放redis对象
			pool.returnResourceObject(jedis);
			e.printStackTrace();
		} finally {
			// 返还到连接池
			returnResource(pool, jedis);
		}

		return bean;
	}

	/**
	 * Get the value of the specified key and convert it to <T> list
	 * 
	 * @param key
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public static <T> List getList(String key, Class<T> type) {
		List list = new ArrayList();

		JedisPool pool = null;
		Jedis jedis = null;
		try {
			pool = getPool();
			jedis = pool.getResource();
			String value = jedis.get(key);
			list = JsonUtil.parseArray(value, type);
		} catch (Exception e) {
			// 释放redis对象
			pool.returnResourceObject(jedis);
			e.printStackTrace();
		} finally {
			// 返还到连接池
			returnResource(pool, jedis);
		}

		return list;
	}

	/**
	 * 自减
	 * 
	 * @param key
	 * @param integer
	 * @return
	 */
	public static Long decrBy(String key, long integer) {
		Long result = null;

		JedisPool pool = null;
		Jedis jedis = null;
		try {
			pool = getPool();
			jedis = pool.getResource();
			result = jedis.decrBy(key, integer);

		} catch (Exception e) {
			// 释放redis对象
			pool.returnResourceObject(jedis);
			e.printStackTrace();
		} finally {
			// 返还到连接池
			returnResource(pool, jedis);
		}
		return result;
	}

	/**
	 * 自减
	 * 
	 * @param key
	 * @param integer
	 * @return
	 */
	public static Long incrBy(String key, long integer) {
		Long result = null;

		JedisPool pool = null;
		Jedis jedis = null;
		try {
			pool = getPool();
			jedis = pool.getResource();
			result = jedis.incrBy(key, integer);
		} catch (Exception e) {
			// 释放redis对象
			pool.returnResourceObject(jedis);
			e.printStackTrace();
		} finally {
			// 返还到连接池
			returnResource(pool, jedis);
		}
		return result;
	}

	/**
	 * put the new value at the end of the list
	 * 
	 * @param key
	 * @param string
	 * @return
	 */
	public static Long rpush(String key, String string) {
		Long result = null;
		JedisPool pool = null;
		Jedis jedis = null;
		try {
			pool = getPool();
			jedis = pool.getResource();
			result = jedis.rpush(key, string);

		} catch (Exception e) {
			// 释放redis对象
			pool.returnResourceObject(jedis);
			e.printStackTrace();
		} finally {
			// 返还到连接池
			returnResource(pool, jedis);
		}
		return result;
	}

	/**
	 * put the new value at the start of the list
	 * 
	 * @param key
	 * @param string
	 * @return
	 */
	public static Long lpush(String key, String string) {
		Long result = null;
		JedisPool pool = null;
		Jedis jedis = null;
		try {
			pool = getPool();
			jedis = pool.getResource();
			result = jedis.lpush(key, string);

		} catch (Exception e) {
			// 释放redis对象
			pool.returnResourceObject(jedis);
			e.printStackTrace();
		} finally {
			// 返还到连接池
			returnResource(pool, jedis);
		}
		return result;
	}

	/**
	 * current length of the list
	 * 
	 * @param key
	 * @return
	 */
	public static int llen(String key) {
		int result = 0;
		JedisPool pool = null;
		Jedis jedis = null;
		try {
			pool = getPool();
			jedis = pool.getResource();
			result = jedis.llen(key).intValue();
		} catch (Exception e) {
			// 释放redis对象
			pool.returnResourceObject(jedis);
			e.printStackTrace();
		} finally {
			// 返还到连接池
			returnResource(pool, jedis);
		}
		return result;
	}

	/**
	 * gives a subset of the list from start to end
	 * 
	 * @param key
	 * @param start
	 * @param end
	 * @return
	 */
	public static List<String> lrange(String key, long start, long end) {
		List<String> result = null;
		JedisPool pool = null;
		Jedis jedis = null;
		try {
			pool = getPool();
			jedis = pool.getResource();
			result = jedis.lrange(key, start, end);

		} catch (Exception e) {
			// 释放redis对象
			pool.returnResourceObject(jedis);
			e.printStackTrace();
		} finally {
			// 返还到连接池
			returnResource(pool, jedis);
		}
		return result;
	}

	/**
	 * remove the first element from the list and returns it
	 * 
	 * @param key
	 * @return
	 */
	public static String lpop(String key) {
		String result = null;
		JedisPool pool = null;
		Jedis jedis = null;
		try {
			pool = getPool();
			jedis = pool.getResource();
			result = jedis.lpop(key);

		} catch (Exception e) {
			// 释放redis对象
			pool.returnResourceObject(jedis);
			e.printStackTrace();
		} finally {
			// 返还到连接池
			returnResource(pool, jedis);
		}
		return result;
	}

	/**
	 * remove the last element from the list and returns it
	 * 
	 * @param key
	 * @return
	 */
	public static String rpop(String key) {
		String result = null;
		JedisPool pool = null;
		Jedis jedis = null;
		try {
			pool = getPool();
			jedis = pool.getResource();
			result = jedis.rpop(key);

		} catch (Exception e) {
			// 释放redis对象
			pool.returnResourceObject(jedis);
			e.printStackTrace();
		} finally {
			// 返还到连接池
			returnResource(pool, jedis);
		}
		return result;
	}

	public static String ltrim(String key, long start, long end) {
		String result = null;
		JedisPool pool = null;
		Jedis jedis = null;
		try {
			pool = getPool();
			jedis = pool.getResource();
			result = jedis.ltrim(key, start, end);

		} catch (Exception e) {
			// 释放redis对象
			pool.returnResourceObject(jedis);
			e.printStackTrace();
		} finally {
			// 返还到连接池
			returnResource(pool, jedis);
		}
		return result;
	}

	/**
	 * <p>
	 * 通过key给field设置指定的值,如果key不存在,则先创建
	 * </p>
	 * 
	 * @param key
	 * @param field
	 * @param value
	 * @return 如果存在返回0 异常返回null
	 */
	public static Long hset(String key, String field, String value) {
		JedisPool pool = null;
		Jedis jedis = null;
		Long res = null;
		try {
			pool = getPool();
			jedis = pool.getResource();
			res = jedis.hset(key, field, value);
		} catch (Exception e) {
			pool.returnResourceObject(jedis);
			e.printStackTrace();
		} finally {
			returnResource(pool, jedis);
		}
		return res;
	}

	/**
	 * <p>
	 * 通过key给field设置指定的值,如果key不存在则先创建,如果field已经存在,返回0
	 * </p>
	 * 
	 * @param key
	 * @param field
	 * @param value
	 * @return
	 */
	public static Long hsetnx(String key, String field, String value) {
		JedisPool pool = null;
		Jedis jedis = null;
		Long res = null;
		try {
			pool = getPool();
			jedis = pool.getResource();
			res = jedis.hsetnx(key, field, value);
		} catch (Exception e) {
			pool.returnResourceObject(jedis);
			e.printStackTrace();
		} finally {
			returnResource(pool, jedis);
		}
		return res;
	}

	/**
	 * <p>
	 * 通过key同时设置 hash的多个field
	 * </p>
	 * 
	 * @param key
	 * @param hash
	 * @return 返回OK 异常返回null
	 */
	public static String hmset(String key, Map<String, String> hash) {
		JedisPool pool = null;
		Jedis jedis = null;
		String res = null;
		try {
			pool = getPool();
			jedis = pool.getResource();
			res = jedis.hmset(key, hash);
		} catch (Exception e) {
			pool.returnResourceObject(jedis);
			e.printStackTrace();
		} finally {
			returnResource(pool, jedis);
		}
		return res;
	}

	/**
	 * <p>
	 * 通过key 和 field 获取指定的 value
	 * </p>
	 * 
	 * @param key
	 * @param field
	 * @return 没有返回null
	 */
	public static String hget(String key, String field) {
		JedisPool pool = null;
		Jedis jedis = null;
		String res = null;
		try {
			pool = getPool();
			jedis = pool.getResource();
			res = jedis.hget(key, field);
		} catch (Exception e) {
			pool.returnResourceObject(jedis);
			e.printStackTrace();
		} finally {
			returnResource(pool, jedis);
		}
		return res;
	}

	/**
	 * <p>
	 * 通过key 和 fields 获取指定的value 如果没有对应的value则返回null
	 * </p>
	 * 
	 * @param key
	 * @param fields
	 *            可以使 一个String 也可以是 String数组
	 * @return
	 */
	public static List<String> hmget(String key, String... fields) {
		JedisPool pool = null;
		Jedis jedis = null;
		List<String> res = null;
		try {
			pool = getPool();
			jedis = pool.getResource();
			res = jedis.hmget(key, fields);
		} catch (Exception e) {
			pool.returnResourceObject(jedis);
			e.printStackTrace();
		} finally {
			returnResource(pool, jedis);
		}
		return res;
	}

	/**
	 * Publish a message to channel.
	 * 
	 * @param channel
	 * @param message
	 * @return Integer reply. The number of message listener is returned.
	 */
	public static Long publish(String channel, Object obj) {
		JedisPool pool = null;
		Jedis jedis = null;
		Long pubIntegerReply = 0l;
		try {
			pool = getPool();
			jedis = pool.getResource();
			pubIntegerReply = jedis.publish(channel, JsonUtil.getJsonStr(obj));
		} catch (Exception e) {
			pool.returnResourceObject(jedis);
			e.printStackTrace();
		} finally {
			returnResource(pool, jedis);
		}
		return pubIntegerReply;
	}
	
	 //*******************************************SortSet Start*******************************************//
	
    /**
     * 向集合中增加一条记录,如果这个值已存在，这个值对应的权重将被置为新的权重
     *
     * @param String
     *            key
     * @param double score 权重
     * @param String
     *            member 要加入的值，
     * @return 状态码 1成功，0已存在member的值
     * */
    public static long zadd(String key, double score, String member) {
    	JedisPool pool = null;
    	Jedis jedis = null;
		Long s = 0l;
		try {
			pool = getPool();
			jedis = pool.getResource();
			s = jedis.zadd(key, score, member);
		} catch (Exception e) {
			pool.returnResourceObject(jedis);
			e.printStackTrace();
		} finally {
			returnResource(pool, jedis);
		}
        return s;
    }

    public static long zadd(String key, Map<String, Double> scoreMembers) {
    	JedisPool pool = null;
    	Jedis jedis = null;
		Long s = 0l;
		try {
			pool = getPool();
			jedis = pool.getResource();
			s = jedis.zadd(key, scoreMembers);
		} catch (Exception e) {
			pool.returnResourceObject(jedis);
			e.printStackTrace();
		} finally {
			returnResource(pool, jedis);
		}
        return s;
    }

    /**
     * 获取集合中元素的数量
     *
     * @param String
     *            key
     * @return 如果返回0则集合不存在
     * */
    public static long zcard(String key) {
    	JedisPool pool = null;
    	Jedis jedis = null;
		Long s = 0l;
		try {
			pool = getPool();
			jedis = pool.getResource();
			s = jedis.zcard(key);
		} catch (Exception e) {
			pool.returnResourceObject(jedis);
			e.printStackTrace();
		} finally {
			returnResource(pool, jedis);
		}
        return s;
    }

    /**
     * 获取指定权重区间内集合的数量
     *
     * @param String
     *            key
     * @param double min 最小排序位置
     * @param double max 最大排序位置
     * */
    public static long zcount(String key, double min, double max) {
    	JedisPool pool = null;
    	Jedis jedis = null;
		Long s = 0l;
		try {
			pool = getPool();
			jedis = pool.getResource();
			s = jedis.zcount(key, min, max);
		} catch (Exception e) {
			pool.returnResourceObject(jedis);
			e.printStackTrace();
		} finally {
			returnResource(pool, jedis);
		}
        return s;
    }

    /**
     * 获得set的长度
     *
     * @param key
     * @return
     */
    public static long zlength(String key) {
    	JedisPool pool = null;
    	Jedis jedis = null;
		Long len = 0l;
		try {
			pool = getPool();
			jedis = pool.getResource();
			 Set<String> set = jedis.zrange(key, 0, -1);
	        len = (long) set.size();
		} catch (Exception e) {
			pool.returnResourceObject(jedis);
			e.printStackTrace();
		} finally {
			returnResource(pool, jedis);
		}
        return len;
    }

    /**
     * 权重增加给定值，如果给定的member已存在
     *
     * @param String
     *            key
     * @param double score 要增的权重
     * @param String
     *            member 要插入的值
     * @return 增后的权重
     * */
    public static double zincrby(String key, double score, String member) {
    	JedisPool pool = null;
    	Jedis jedis = null;
		Double s=0.0;
		try {
			pool = getPool();
			jedis = pool.getResource();
			s = jedis.zincrby(key, score, member);
		} catch (Exception e) {
			pool.returnResourceObject(jedis);
			e.printStackTrace();
		} finally {
			returnResource(pool, jedis);
		}
        return s;
    }

    /**
     * 返回指定位置的集合元素,0为第一个元素，-1为最后一个元素
     *
     * @param String
     *            key
     * @param int start 开始位置(包含)
     * @param int end 结束位置(包含)
     * @return Set<String>
     * */
    public static Set<String> zrange(String key, int start, int end) {
    	JedisPool pool = null;
    	Jedis jedis = null;
    	Set<String> set = null;
		try {
			pool = getPool();
			jedis = pool.getResource();
			set = jedis.zrange(key, start, end);
		} catch (Exception e) {
			pool.returnResourceObject(jedis);
			e.printStackTrace();
		} finally {
			returnResource(pool, jedis);
		}
        return set;
    }

    /**
     * 返回指定权重区间的元素集合
     *
     * @param String
     *            key
     * @param double min 上限权重
     * @param double max 下限权重
     * @return Set<String>
     * */
    public static Set<String> zrangeByScore(String key, double min, double max) {
    	JedisPool pool = null;
    	Jedis jedis = null;
    	Set<String> set = null;
		try {
			pool = getPool();
			jedis = pool.getResource();
			set = jedis.zrangeByScore(key, min, max);
		} catch (Exception e) {
			pool.returnResourceObject(jedis);
			e.printStackTrace();
		} finally {
			returnResource(pool, jedis);
		}
        return set;
    }

    /**
     * 获取指定值在集合中的位置，集合排序从低到高
     *
     * @see zrevrank
     * @param String
     *            key
     * @param String
     *            member
     * @return long 位置
     * */
    public static long zrank(String key, String member) {
    	JedisPool pool = null;
    	Jedis jedis = null;
		Long s = 0l;
		try {
			pool = getPool();
			jedis = pool.getResource();
			s = jedis.zrank(key, member);
		} catch (Exception e) {
			pool.returnResourceObject(jedis);
			e.printStackTrace();
		} finally {
			returnResource(pool, jedis);
		}
        return s;
    }

    /**
     * 获取指定值在集合中的位置，集合排序从高到低
     *
     * @see zrank
     * @param String key
     * @param String member
     * @return long 位置
     * */
    public static long zrevrank(String key, String member) {
    	JedisPool pool = null;
    	Jedis jedis = null;
		Long s = 0l;
		try {
			pool = getPool();
			jedis = pool.getResource();
			s = jedis.zrevrank(key, member);
		} catch (Exception e) {
			pool.returnResourceObject(jedis);
			e.printStackTrace();
		} finally {
			returnResource(pool, jedis);
		}
        return s;
    }

    /**
     * 从集合中删除成员
     *
     * @param String key
     * @param String member
     * @return 返回1成功
     * */
    public static long zrem(String key, String member) {
    	JedisPool pool = null;
    	Jedis jedis = null;
		Long s = 0l;
		try {
			pool = getPool();
			jedis = pool.getResource();
			s = jedis.zrem(key, member);
		} catch (Exception e) {
			pool.returnResourceObject(jedis);
			e.printStackTrace();
		} finally {
			returnResource(pool, jedis);
		}
        return s;
    }

    /**
     * 删除
     *
     * @param key
     * @return
     */
    public static long zrem(String key) {
    	JedisPool pool = null;
    	Jedis jedis = null;
		Long s = 0l;
		try {
			pool = getPool();
			jedis = pool.getResource();
			s = jedis.del(key);
		} catch (Exception e) {
			pool.returnResourceObject(jedis);
			e.printStackTrace();
		} finally {
			returnResource(pool, jedis);
		}
        return s;
    }

    /**
     * 删除给定位置区间的元素
     *
     * @param String
     *            key
     * @param int start 开始区间，从0开始(包含)
     * @param int end 结束区间,-1为最后一个元素(包含)
     * @return 删除的数量
     * */
    public static long zremrangeByRank(String key, int start, int end) {
    	JedisPool pool = null;
    	Jedis jedis = null;
		Long s = 0l;
		try {
			pool = getPool();
			jedis = pool.getResource();
			s = jedis.zremrangeByRank(key, start, end);
		} catch (Exception e) {
			pool.returnResourceObject(jedis);
			e.printStackTrace();
		} finally {
			returnResource(pool, jedis);
		}
        return s;
    }

    /**
     * 删除给定权重区间的元素
     *
     * @param String
     *            key
     * @param double min 下限权重(包含)
     * @param double max 上限权重(包含)
     * @return 删除的数量
     * */
    public static long zremrangeByScore(String key, double min, double max) {
    	JedisPool pool = null;
    	Jedis jedis = null;
		Long s = 0l;
		try {
			pool = getPool();
			jedis = pool.getResource();
			s = jedis.zremrangeByScore(key, min, max);
		} catch (Exception e) {
			pool.returnResourceObject(jedis);
			e.printStackTrace();
		} finally {
			returnResource(pool, jedis);
		}
        return s;
    }

    /**
     * 获取给定区间的元素，原始按照权重由高到低排序
     *
     * @param String  key
     * @param int start
     * @param int end
     * @return Set<String>
     * */
    public static Set<String> zrevrange(String key, int start, int end) {
    	JedisPool pool = null;
    	Jedis jedis = null;
    	Set<String> set = null;
		try {
			pool = getPool();
			jedis = pool.getResource();
			set = jedis.zrevrange(key, start, end);
		} catch (Exception e) {
			pool.returnResourceObject(jedis);
			e.printStackTrace();
		} finally {
			returnResource(pool, jedis);
		}
        return set;
    }

    /**
     * 获取给定值在集合中的权重
     * @param String  key
     * @param memeber
     * @return double 权重
     * */
    public static double zscore(String key, String memebr) {
    	JedisPool pool = null;
    	Jedis jedis = null;
		Double s=0.0;
		try {
			pool = getPool();
			jedis = pool.getResource();
			s = jedis.zscore(key, memebr);
		} catch (Exception e) {
			pool.returnResourceObject(jedis);
			e.printStackTrace();
		} finally {
			returnResource(pool, jedis);
		}
        return s;
    }
    
  //*******************************************SortSet End*******************************************//
}
