package com.kungfu.kms.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import com.kungfu.kms.domain.Role;

@Repository
public interface RoleMapper {
	@Select("select * from t_role limit #{start} , #{count}")
	List<Role> getRoleList(@Param("start")int start,@Param("count")int count);
}
