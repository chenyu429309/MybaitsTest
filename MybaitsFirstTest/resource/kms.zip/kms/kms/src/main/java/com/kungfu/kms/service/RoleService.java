package com.kungfu.kms.service;

import java.util.List;

import com.kungfu.kms.domain.Role;

/**
 * 角色管理模块
 * @author lenovo
 *
 */
public interface RoleService {
	public List<Role> getRoleList();
}
