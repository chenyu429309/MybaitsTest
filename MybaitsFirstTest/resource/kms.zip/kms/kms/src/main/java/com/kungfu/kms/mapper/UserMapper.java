package com.kungfu.kms.mapper;

import org.apache.ibatis.annotations.Select;

import com.kungfu.kms.domain.UserInfo;

public interface UserMapper {

	@Select("select * from t_user where account=#{account}")
	UserInfo findByAccount(String account);
}
